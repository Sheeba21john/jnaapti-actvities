Use nodemon to start app.js as well as mongodb using following command:

service mongod start
